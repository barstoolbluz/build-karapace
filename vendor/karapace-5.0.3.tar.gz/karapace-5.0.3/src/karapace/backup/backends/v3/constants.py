"""
Copyright (c) 2023 Aiven Ltd
See LICENSE for details
"""

from typing import Final

V3_MARKER: Final = b"/V3\n"
