Credentials used for testing
