About Karapace
==============

There are lots of reasons to use schemas alongside your Kafka payloads; Karapace gives you an open source solution for handling your schemas for the following data formats

- Json
- Avro
- Protobuf
